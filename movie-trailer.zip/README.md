
# Getting Started with Create React App



## Available Scripts

In the project directory, you can run:

### npm start

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.




📌API_IMG="https://image.tmdb.org/t/p/w500/"

📌API_SEARCH="https://api.themoviedb.org/3/search/movie?api_key=<<api_key_here>>&query"
📌API_URL=https://api.themoviedb.org/3/movie/11?api_key=e4213465dfacc08ac8385402206f9c3d'
